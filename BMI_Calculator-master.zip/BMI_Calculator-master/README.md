# BMI_Calculator

<p>
    <img src="/BMI_Calculator/screenshot.jpg"/>
</p>