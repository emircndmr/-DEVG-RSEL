using BMI_Calculator.MVVM.ViewModels;

namespace BMI_Calculator.MVVM.Views;

public partial class BMIView : ContentPage
{
	public BMIView()
	{
		InitializeComponent();
		BindingContext = new BMIViewModel();
	}
}